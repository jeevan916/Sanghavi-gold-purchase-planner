
import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, History, Settings as SettingsIcon, 
  MessageSquare, UserCircle, Menu, X, ReceiptIndianRupee, 
  ListFilter, ShieldAlert, Globe, Layers, BrainCircuit, PlusCircle, BookOpen
} from 'lucide-react';

import Dashboard from './components/Dashboard';
import OrderForm from './components/OrderForm';
import Settings from './components/Settings';
import CustomerList from './components/CustomerList';
import OrderDetails from './components/OrderDetails';
import CustomerOrderView from './components/CustomerOrderView';
import WhatsAppPanel from './components/WhatsAppPanel';
import WhatsAppTemplates from './components/WhatsAppTemplates';
import ErrorLogPanel from './components/ErrorLogPanel'; 
import PaymentCollections from './components/PaymentCollections';
import WhatsAppLogs from './components/WhatsAppLogs';
import MarketIntelligence from './components/MarketIntelligence';
import PlanManager from './components/PlanManager';

import { useOrders } from './hooks/useOrders';
import { useWhatsApp } from './hooks/useWhatsApp';
import { Order, OrderStatus, GlobalSettings, Customer, AppError, ActivityLogEntry, ProductionStatus } from './types';
import { INITIAL_SETTINGS, INITIAL_PLAN_TEMPLATES } from './constants';
import { goldRateService } from './services/goldRateService';
import { errorService } from './services/errorService';

const App: React.FC = () => {
  type Tab = 'dashboard' | 'orders' | 'settings' | 'collections' | 'customers' | 'whatsapp' | 'waLogs' | 'templates' | 'errors' | 'market' | 'plans';
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isCreating, setIsCreating] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [selectedContact, setSelectedContact] = useState<string | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [publicOrder, setPublicOrder] = useState<Order | null>(null);
  const [publicError, setPublicError] = useState<string | null>(null);

  // Custom Hooks
  const { orders, addOrder, updateOrder, recordPayment, updateItemStatus } = useOrders();
  const { logs, templates, setTemplates, addLog } = useWhatsApp();
  const [settings, setSettings] = useState<GlobalSettings>(() => {
    const saved = localStorage.getItem('aura_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });
  const [planTemplates, setPlanTemplates] = useState(() => {
    const saved = localStorage.getItem('aura_plans');
    return saved ? JSON.parse(saved) : INITIAL_PLAN_TEMPLATES;
  });

  const [systemErrors, setSystemErrors] = useState<AppError[]>([]); 
  const [activityLogs, setActivityLogs] = useState<ActivityLogEntry[]>([]); 

  // Derived Customers List
  const customers = useMemo(() => {
    const customerMap = new Map<string, Customer>();
    orders.forEach(order => {
      const contact = order.customerContact;
      if (!customerMap.has(contact)) {
        customerMap.set(contact, {
          id: `CUST-${contact}`,
          name: order.customerName,
          contact: order.customerContact,
          secondaryContact: order.secondaryContact,
          email: order.customerEmail,
          orderIds: [order.id],
          totalSpent: order.totalAmount,
          joinDate: order.createdAt,
        });
      } else {
        const existing = customerMap.get(contact)!;
        if (!existing.orderIds.includes(order.id)) {
          existing.orderIds.push(order.id);
          existing.totalSpent += order.totalAmount;
        }
      }
    });
    return Array.from(customerMap.values());
  }, [orders]);

  useEffect(() => {
    const unsubscribe = errorService.subscribe((errs, acts) => {
      setSystemErrors([...errs]);
      setActivityLogs([...acts]);
    });
    
    const params = new URLSearchParams(window.location.search);
    const viewToken = params.get('view');
    if (viewToken) {
      const target = orders.find(o => o.shareToken === viewToken);
      if (target) setPublicOrder(target);
      else setPublicError("Invalid Link.");
    } else {
      goldRateService.fetchLiveRate(false).then(res => {
        if(res.success) setSettings(p => ({...p, currentGoldRate24K: res.rate24K, currentGoldRate22K: res.rate22K}));
      });
    }
    return unsubscribe;
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('aura_settings', JSON.stringify(settings));
    localStorage.setItem('aura_plans', JSON.stringify(planTemplates));
  }, [settings, planTemplates]);

  if (publicOrder) return <CustomerOrderView order={publicOrder} />;
  if (publicError) return <div className="min-h-screen flex items-center justify-center p-6 text-center"><h2>Access Denied</h2><p>{publicError}</p></div>;

  const NavContent = () => (
    <nav className="flex-1 px-4 space-y-1">
      <div className="p-8 hidden lg:block"><h1 className="text-2xl font-black text-amber-600 tracking-tighter">AuraGold</h1></div>
      <button onClick={() => setActiveTab('dashboard')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'dashboard' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><LayoutDashboard size={20} /> Dashboard</button>
      <button onClick={() => setActiveTab('market')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'market' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><Globe size={20} /> Market Watch</button>
      <button onClick={() => setActiveTab('orders')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'orders' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><History size={20} /> History</button>
      <button onClick={() => setActiveTab('collections')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'collections' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><ReceiptIndianRupee size={20} /> Collections</button>
      <div className="pt-4 pb-2 px-2 text-[10px] font-black uppercase text-slate-400">Automation</div>
      <button onClick={() => setActiveTab('plans')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'plans' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><Layers size={20} /> Plan Architect</button>
      <button onClick={() => setActiveTab('templates')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'templates' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><BrainCircuit size={20} /> AI Templates</button>
      <div className="pt-4 pb-2 px-2 text-[10px] font-black uppercase text-slate-400">System</div>
      <button onClick={() => setActiveTab('whatsapp')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'whatsapp' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><MessageSquare size={20} /> Chat Console</button>
      <button onClick={() => setActiveTab('waLogs')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'waLogs' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><ListFilter size={20} /> Comm. Logs</button>
      <button onClick={() => setActiveTab('errors')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'errors' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><ShieldAlert size={20} /> System Logs</button>
      <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'settings' ? 'bg-amber-50 text-amber-700' : 'text-slate-500 hover:bg-slate-50'}`}><SettingsIcon size={20} /> Settings</button>
    </nav>
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-50 font-sans">
      <header className="lg:hidden bg-white border-b px-6 py-4 flex justify-between items-center"><h1 className="text-xl font-black text-amber-600">AuraGold</h1><button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2">{isMenuOpen ? <X /> : <Menu />}</button></header>
      {isMenuOpen && <div className="lg:hidden fixed inset-0 bg-black/50 z-40" onClick={() => setIsMenuOpen(false)}><div className="w-64 h-full bg-white"><NavContent /></div></div>}
      <aside className="w-64 bg-white border-r hidden lg:flex flex-col h-screen sticky top-0 overflow-y-auto custom-scrollbar"><NavContent /></aside>
      
      <main className="flex-1 overflow-auto p-4 md:p-8">
        {!selectedOrderId && !isCreating && (
          <header className="flex flex-col sm:flex-row justify-between gap-4 mb-8">
            <div><h2 className="text-2xl font-bold text-slate-800 capitalize">{activeTab}</h2><p className="text-sm text-slate-500">AuraGold Recovery Backend</p></div>
            <button onClick={() => setIsCreating(true)} className="bg-amber-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-amber-700 shadow-lg transition-all"><PlusCircle size={20} /> New Order</button>
          </header>
        )}

        {isCreating ? <OrderForm settings={settings} planTemplates={planTemplates} existingCustomers={customers} onSubmit={addOrder} onCancel={() => setIsCreating(false)} /> :
         selectedOrderId ? (
           <OrderDetails 
              order={orders.find(o => o.id === selectedOrderId)!} 
              settings={settings} 
              onBack={() => setSelectedOrderId(null)} 
              onUpdateStatus={(itemId, status) => updateItemStatus(selectedOrderId, itemId, status)}
              onRecordPayment={recordPayment}
              onOrderUpdate={updateOrder}
              logs={logs}
              onAddLog={addLog}
           />
         ) :
         <>
           {activeTab === 'dashboard' && <Dashboard orders={orders} currentRates={{ k24: settings.currentGoldRate24K, k22: settings.currentGoldRate22K }} />}
           {activeTab === 'collections' && <PaymentCollections orders={orders} onViewOrder={setSelectedOrderId} onSendWhatsApp={() => {}} settings={settings} />}
           {activeTab === 'customers' && <CustomerList customers={customers} orders={orders} onViewOrder={setSelectedOrderId} onMessageSent={addLog} />}
           {activeTab === 'whatsapp' && <WhatsAppPanel logs={logs} customers={customers} onRefreshStatus={() => {}} templates={templates} initialContact={selectedContact} onAddLog={addLog} />}
           {activeTab === 'market' && <MarketIntelligence />}
           {activeTab === 'plans' && <PlanManager templates={planTemplates} onUpdate={setPlanTemplates} />}
           {activeTab === 'templates' && <WhatsAppTemplates templates={templates} onUpdate={setTemplates} />}
           {activeTab === 'waLogs' && <WhatsAppLogs logs={logs} onViewChat={(phone) => { setActiveTab('whatsapp'); setSelectedContact(phone); }} />}
           {activeTab === 'errors' && <ErrorLogPanel errors={systemErrors} activities={activityLogs} onClear={() => { errorService.clearErrors(); errorService.clearActivity(); }} />}
           {activeTab === 'settings' && <Settings settings={settings} onUpdate={setSettings} />}
           {activeTab === 'orders' && (
             <div className="grid gap-4">{orders.map(o => (
               <div key={o.id} onClick={() => setSelectedOrderId(o.id)} className="bg-white p-6 rounded-2xl border flex gap-6 hover:shadow-lg cursor-pointer transition-all">
                  <div className="w-16 h-16 bg-slate-100 rounded-xl overflow-hidden shrink-0 border"><img src={o.items[0]?.photoUrls[0]} className="w-full h-full object-cover" /></div>
                  <div><h3 className="font-bold">{o.customerName}</h3><p className="text-sm text-slate-500">₹{o.totalAmount.toLocaleString()} • {o.status}</p></div>
               </div>
             ))}</div>
           )}
         </>
        }
      </main>
    </div>
  );
};

export default App;
