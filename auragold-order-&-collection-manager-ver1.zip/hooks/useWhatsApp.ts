
import { useState, useEffect } from 'react';
import { WhatsAppLogEntry, WhatsAppTemplate } from '../types';
import { INITIAL_TEMPLATES } from '../constants';

export function useWhatsApp() {
  const [logs, setLogs] = useState<WhatsAppLogEntry[]>([]);
  const [templates, setTemplates] = useState<WhatsAppTemplate[]>(INITIAL_TEMPLATES);

  useEffect(() => {
    const savedLogs = localStorage.getItem('aura_whatsapp_logs');
    if (savedLogs) setLogs(JSON.parse(savedLogs));
    
    const savedTpls = localStorage.getItem('aura_whatsapp_templates');
    if (savedTpls) setTemplates(JSON.parse(savedTpls));
  }, []);

  useEffect(() => {
    localStorage.setItem('aura_whatsapp_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('aura_whatsapp_templates', JSON.stringify(templates));
  }, [templates]);

  const addLog = (log: WhatsAppLogEntry) => {
    setLogs(prev => [log, ...prev]);
  };

  return { logs, setLogs, templates, setTemplates, addLog };
}
